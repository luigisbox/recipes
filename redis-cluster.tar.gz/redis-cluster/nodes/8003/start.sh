#!/usr/bin/env bash
cd /nodes/8003 && redis-server redis.conf
