#!/usr/bin/env bash
cd /nodes/8002 && redis-server redis.conf
