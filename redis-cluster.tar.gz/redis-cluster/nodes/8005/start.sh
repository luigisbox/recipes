#!/usr/bin/env bash
cd /nodes/8005 && redis-server redis.conf
