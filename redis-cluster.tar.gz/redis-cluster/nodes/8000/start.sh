#!/usr/bin/env bash
cd /nodes/8000 && redis-server redis.conf
