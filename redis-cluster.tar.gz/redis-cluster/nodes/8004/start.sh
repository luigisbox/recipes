#!/usr/bin/env bash
cd /nodes/8004 && redis-server redis.conf
