#!/usr/bin/env bash
cd /nodes/8001 && redis-server redis.conf
